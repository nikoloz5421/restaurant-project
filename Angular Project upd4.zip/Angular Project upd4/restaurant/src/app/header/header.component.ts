import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { BasketComponent } from '../basket/basket.component';

@Component({
  selector: 'app-header',
  imports: [RouterModule, HomeComponent, BasketComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

}
