import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { Product } from '../models/product.module';

export interface BasketItem {
  id?: number;
  quantity: number;
  price: number;
  productId: number;
  product?: Product;
  clientId?: number;
}

@Injectable({
  providedIn: 'root',
})
export class BasketService {
  private apiUrl = 'https://restaurant.stepprojects.ge/api/Baskets';
  private basketItemsSubject = new BehaviorSubject<BasketItem[]>([]);
  public basketItems$ = this.basketItemsSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadBasket();
  }

  loadBasket(): void {
    this.http
      .get<BasketItem[]>(`${this.apiUrl}/GetAll`)
      .pipe(
        catchError(() => {
          return [];
        })
      )
      .subscribe((items) => {
        const itemsWithIndex = items.map((item, index) => {
          return {
            ...item,
            clientId: index,
            quantity: item.quantity || 1,
          };
        });
        this.basketItemsSubject.next(itemsWithIndex || []);
      });
  }

  getBasketItems(): Observable<BasketItem[]> {
    return this.basketItems$;
  }

  addToBasket(product: Product, quantity: number = 1): Observable<BasketItem> {
    const basketItem: BasketItem = {
      quantity: 1,
      price: product.price,
      productId: product.id,
    };

    return this.http
      .post<BasketItem>(`${this.apiUrl}/AddToBasket`, basketItem)
      .pipe(
        tap(() => {
          this.loadBasket();
        }),
        catchError((error) => {
          throw error;
        })
      );
  }

  updateBasketItem(basketItem: BasketItem): Observable<any> {
    const productIdToUse = basketItem.product?.id || basketItem.productId;

    if (productIdToUse) {
      const updatedItem = {
        quantity: basketItem.quantity,
        price: basketItem.price,
        productId: productIdToUse,
      };

      const currentItems = this.basketItemsSubject.getValue();
      const index = currentItems.findIndex(
        (item) =>
          item.product?.id === productIdToUse ||
          item.productId === productIdToUse
      );

      if (index !== -1) {
        const updatedItems = [...currentItems];
        updatedItems[index] = {
          ...currentItems[index],
          quantity: basketItem.quantity,
        };
        this.basketItemsSubject.next(updatedItems);
      }

      return this.http
        .delete(`${this.apiUrl}/DeleteProduct/${productIdToUse}`)
        .pipe(
          tap(() => {
            return this.http
              .post<BasketItem>(`${this.apiUrl}/AddToBasket`, updatedItem)
              .pipe(
                tap(() => {}),
                catchError((addError) => {
                  return of({ error: addError });
                })
              )
              .subscribe();
          }),
          catchError(() => {
            return this.http
              .post<BasketItem>(`${this.apiUrl}/AddToBasket`, updatedItem)
              .pipe(
                tap(() => {
                  this.loadBasket();
                }),
                catchError((addError) => {
                  return of({ error: addError });
                })
              );
          })
        );
    } else {
      return throwError(() => new Error('No valid product ID for update'));
    }
  }

  removeFromBasket(
    id: number | undefined,
    productId?: number,
    clientId?: number
  ): Observable<any> {
    const currentItems = this.basketItemsSubject.getValue();
    const itemToRemove =
      clientId !== undefined ? currentItems[clientId] : undefined;
    const productIdToUse = itemToRemove?.product?.id;

    if (productIdToUse) {
      return this.http
        .delete(`${this.apiUrl}/DeleteProduct/${productIdToUse}`)
        .pipe(
          tap(() => {
            this.loadBasket();
          }),
          catchError((error) => {
            throw error;
          })
        );
    } else {
      return throwError(() => new Error('No valid product ID found to delete'));
    }
  }

  getTotalItems(): Observable<number> {
    return new Observable<number>((observer) => {
      this.basketItems$.subscribe((items) => {
        const total = items.reduce((sum, item) => sum + item.quantity, 0);
        observer.next(total);
      });
    });
  }

  getTotalPrice(): Observable<number> {
    return new Observable<number>((observer) => {
      this.basketItems$.subscribe((items) => {
        const total = items.reduce(
          (sum, item) => sum + item.price * item.quantity,
          0
        );
        observer.next(total);
      });
    });
  }

  inspectBasketItems(): void {
    this.http
      .get<any>(`${this.apiUrl}/GetAll`, { observe: 'response' })
      .subscribe(
        (response) => {
          if (Array.isArray(response.body)) {
            const sampleItem = response.body[0];
            if (sampleItem) {
              Object.keys(sampleItem).forEach((key) => {
                if (
                  key.toLowerCase().includes('id') ||
                  key === 'id' ||
                  key === '_id'
                ) {}
              });
            }
          }
        },
        () => {}
      );
  }

  testDeleteMethods(item: BasketItem): void {
    if (item.id) {
      this.http.delete(`${this.apiUrl}/DeleteProduct/${item.id}`).subscribe(
        () => {},
        () => {}
      );
    }

    if (item.productId) {
      this.http
        .delete(`${this.apiUrl}/DeleteProduct/${item.productId}`)
        .subscribe(
          () => {},
          () => {}
        );
    }

    if (item.product?.id) {
      this.http
        .delete(`${this.apiUrl}/DeleteProduct/${item.product.id}`)
        .subscribe(
          () => {},
          () => {}
        );
    }

    this.http
      .request('delete', `${this.apiUrl}/DeleteProduct`, { body: item })
      .subscribe(
        () => {},
        () => {}
      );

    this.http
      .request('delete', this.apiUrl, {
        body: { productId: item.productId },
      })
      .subscribe(
        () => {},
        () => {}
      );
  }
}