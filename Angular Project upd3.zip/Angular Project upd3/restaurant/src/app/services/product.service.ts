import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../models/product.module';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'https://restaurant.stepprojects.ge/api/Products'
  constructor(private http: HttpClient) { }

  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}/GetAll`)
  }

  getFilteredProducts(filters: any): Observable<Product[]> {
    let params = new HttpParams();
    if (filters) {
      Object.keys(filters).forEach(key => {
        if (filters[key] !== undefined && filters[key] !== null && filters[key] !== '') {
          params = params.set(key, filters[key]);
        }
      });
    }
    return this.http.get<Product[]>(`${this.apiUrl}/GetFiltered`, { params });
  }
}